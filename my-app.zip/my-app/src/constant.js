let ride = [
  {
    name: "XYZ",
    vehicleNumber: "DIMMY",
    pickup: "JAYANAGR",
    destination: "E CITY",
    time: "22-03-2020 12:23:12",
    type: "CAR",
    seats: "4"
  }
];
export default ride;
